import { Button } from "../components/Button"
import { Input } from "../components/Input"
import { Output } from "../components/Output"
import {useState} from 'react';

export const Greet = ()=>{
    const [firstName, setFirstName] = useState("");
    const [lastName, setLastName] = useState("");
    const [fullName, setFullName] = useState("");
    const takeFirstName = (evt)=>{
        //firstName = evt.target.value;
        setFirstName(evt.target.value);
        console.log('First Name Call ', evt.target.value);
        
    }
    const takeLastName = (event)=>{
        //lastName = event.target.value;
        setLastName(event.target.value);
        console.log('Last Name Call ', event);
        
    }
    const initCap = (str)=>
             str.charAt(0).toUpperCase() + str.substring(1).toLowerCase();
    
    const showFullName = ()=>{
        const concateName = initCap(firstName) +" "+ initCap(lastName);
        console.log('Full Name ', concateName);
        setFullName(concateName);
    }

    const clearAll = ()=>{
        setFullName ("");
        setFirstName("");
        setLastName("");
    }

    return <div className = 'container'>
        <Output result = "Greet App"/> 
        <Input val={firstName} fn={takeFirstName} labelValue="First Name" />
        <Input val={lastName} fn = {takeLastName} labelValue="Last Name" />
        <Button fn = {showFullName} cssClass="btn btn-primary" label="Greet"/>
        &nbsp;
        <Button fn = {clearAll} cssClass="btn btn-danger" label="Clear All"/>
         <Output  result = {fullName}/>   
    </div>
}