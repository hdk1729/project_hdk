export const Button = ({label, cssClass, fn})=>{
    return (<button onClick={fn} className = {cssClass}>{label}</button>)
}